%Comment and Uncomment when necessary 

%Question 1 part a and b

%{
load('hw4_data3.mat')

sigma = [0.01, 0.07, 0.15, 1.5, 2];


y_predict = cell(length(sigma),1);
accuracy = zeros(length(sigma),1);

fprintf('Sigma    Accuracy\n');
fprintf('-----    --------\n');

for i = 1:length(sigma)
   y_predict{i} = weightedKNN(X_train,y_train,X_test,sigma(i));
   accuracy(i) = mean(y_predict{i} == y_test)*100;
    
   fprintf('%.2f     %.2f%%\n', sigma(i), accuracy(i));

end
%}

%Question 2.1
% Face dataset part

%https://www.mathworks.com/matlabcentral/answers/35360-randomly-accessing-a-file-from-a-folder-using-matlab
%This Website helped me
filepath = 'C:\Users\there\Downloads\ps5_Matlab_Coyne_Kevin\input';
facepath = fullfile(filepath, 'all', 'HW5_att_faces');

%needed to replace all files after run
delete(fullfile(filepath, 'train', '*.pgm'));
delete(fullfile(filepath, 'test', '*.pgm'));

f = dir(facepath);
f = f([f.isdir] & ~ismember({f.name}, {'.', '..'}));



for i = 1:numel(f)
    subject_path = fullfile(facepath, f(i).name);
    images = dir(fullfile(subject_path, '*.pgm'));

    
    all_indices = 1:10;
    train_indices = randperm(10, 8);
    
    person_id = str2double(f(i).name(2:end));
    
    %loop for training samples
    for j = 1:length(train_indices)
        img_name = images(train_indices(j)).name;
        img = imread(fullfile(subject_path, img_name));
        new_name = sprintf('%d_%d.pgm', person_id, train_indices(j));
        imwrite(img, fullfile(filepath, 'train', new_name));

    end
    
    %loop for testing samples 
    test_indices = setdiff(all_indices, train_indices);
    for j = 1:length(test_indices)
        img_name = images(test_indices(j)).name;
        img = imread(fullfile(subject_path, img_name));
        new_name = sprintf('%d_%d.pgm', person_id, test_indices(j));
        imwrite(img, fullfile(filepath, 'test', new_name));
    end
end
%format of each file n_m.pgm n=Person ID m=imagenumber of subject

randomPersonId = randi(person_id, 1, 3);
randomTrainIter = randi(size(train_indices),1,3);

%NOTE::
%I have tried multiple different ways to display my images and I dont care
%enough to fix them given the time I had to do this. I believe this to be a
%matlab issue. The version of matlab is Matlab2024 i am using and for all
%the ones I display images will be commented out so You can see what I put
%and attempted but the graphs wont show up in the files

%figure;
for i = 1:3
    img_name = sprintf('%d_%d.pgm', randomPersonId(i), randomTrainIter(i));
    img_path = fullfile(filepath, 'train', img_name);
    %img = imread(img_path);
    
    %subplot(1, 3, i);
    %imagesc(img);
    %colormap gray;
    %axis image;
    %title(sprintf('Person %d', randomPersonId(i)));
    %saveas(gcf,'ps5-2-0.png');
end

%a

filepath = 'C:\Users\there\Downloads\ps5_Matlab_Coyne_Kevin\input';
train_path = fullfile(filepath, 'train');

% Read all training images
train_files = dir(fullfile(train_path, '*.pgm'));
num_images = length(train_files);
image_size = 112 * 92; % 112x92 pixels


T = zeros(image_size, num_images);

% Read and reshape each image into column vectors
for i = 1:num_images
    img_path = fullfile(train_path, train_files(i).name);
    img = imread(img_path);
    T(:, i) = img(:); % Reshape to column vector
end

% Display matrix T as image
%figure;
%imshow(T, []);
%title('Matrix T (10304 x 320)');
%saveas(gcf, 'ps5-1-a.png');

% imshow(T, []);

%part b
% Compute the average face vector m
m = mean(T, 2);

% Resize m to 112x92 and display
mean_face = reshape(m, 112, 92);
%figure;
%imshow(mean_face, []);
%title('Mean Face');
%saveas(gcf, 'ps5-2-1-b.png');

%part c
A = T - m;

CovarMatrix = A*A';

%figure;
%imshow(CovarMatrix, []);
%title('Covariance Matrix C (10304x10304)');
%saveas(gcf, 'ps5-2-1-c.png');

%part d
temp = A' * A;  % This is the 320x320 matrix

% Compute eigenvalues of temp
[eig_vecs, eig_vals] = eig(temp);
lambda = diag(eig_vals);  % Extract eigenvalues from diagonal
[lambda_sorted, idx] = sort(lambda, 'descend');

% Compute cumulative variance
total_variance = sum(lambda_sorted);
cumulative_variance = cumsum(lambda_sorted) / total_variance;

% Find minimum k for 95% variance
K = find(cumulative_variance >= 0.95, 1);


%disp(K);
figure;
plot(1:length(cumulative_variance), cumulative_variance, 'LineWidth', 2);
xlabel('k');
ylabel('v(k)');
saveas(gcf, 'ps5-2-1-d.png')


%part e
[U, D] = eigs(CovarMatrix, K);  % U contains the K best eigenvectors

%figure;
for n = 1:9
    eigenface = reshape(U(:, n), 112, 92);
    %subplot(3, 3, i);
    %imshow(eigenface, []);
    %title(sprintf('Eigenface %d', i));
end

%saveas(gcf, 'ps5-2-1-e.png');

%Question 2.2
%part a
W_training = zeros(num_images,K);
y_train = zeros(num_images, 1);

for i = 1:num_images
    I = T(:,i);
    I_centered = I - m; %centered image

    w = U' * I_centered; %reduced eigenspace

    W_training(i,:) = w';

    filename = train_files(i).name;
    person_id = sscanf(filename, '%d_%d.pgm');
    y_train(i) = person_id(1);
end

%part b

test_path = fullfile(filepath, 'test');
test_files = dir(fullfile(test_path, '*.pgm'));
num_test_images = length(test_files);


W_testing = zeros(num_test_images,K);
y_test = zeros(num_test_images, 1);

for s = 1:num_test_images

    img_path = fullfile(test_path, test_files(s).name);
    I2 = imread(img_path);
    I2 = double(I2(:)); %resize

    I2_centered = I2 - m; %centered image

    w2 = U' * I2_centered; %reduced eigenspace

    W_testing(s,:) = w2';

    filename = test_files(s).name;
    person_id = sscanf(filename, '%d_%d.pgm');
    y_test(s) = person_id(1);
end

%Question 2.3
%part a

W_training_norm = normalize(W_training, 'zscore'); 
W_testing_norm = normalize(W_testing, 'zscore');

k_values = [1, 3, 5, 7, 9, 11];
accuracy_knn = zeros(length(k_values), 1);

fprintf('KNN Classifier Accuracy:\n');
fprintf('K    Accuracy\n');
fprintf('--   --------\n');

for i = 1:length(k_values)
    k = k_values(i);
    %training
    knn_model = fitcknn(W_training_norm, y_train, 'NumNeighbors', k);
    % Testing
    y_pred = predict(knn_model, W_testing_norm);
    % Compute accuracy
    correct_predictions = sum(y_pred == y_test);
    total_samples = length(y_test);
    accuracy_knn(i) = (correct_predictions / total_samples) * 100;
    
    fprintf('%d    %.2f%%\n', k, accuracy_knn(i));
end

%part b - SVM Classifiers

% Initialize arrays for results
training_time = zeros(3,2); % 3 kernels x 2 multi-class methods
testing_accuracy = zeros(3,2);

fprintf('Training SVM classifiers...\n\n');

% 1. Linear Kernel
% One-vs-One
tic;
svm_linear_ovo = fitcecoc(W_training_norm, y_train, 'Coding', 'onevsone', ...
                          'Learners', templateSVM('KernelFunction', 'linear', 'Standardize', true));
training_time(1,1) = toc;
y_pred_linear_ovo = predict(svm_linear_ovo, W_testing_norm);
testing_accuracy(1,1) = sum(y_pred_linear_ovo == y_test) / length(y_test) * 100;

% One-vs-All
tic;
svm_linear_ova = fitcecoc(W_training_norm, y_train, 'Coding', 'onevsall', ...
                          'Learners', templateSVM('KernelFunction', 'linear', 'Standardize', true));
training_time(1,2) = toc;
y_pred_linear_ova = predict(svm_linear_ova, W_testing_norm);
testing_accuracy(1,2) = sum(y_pred_linear_ova == y_test) / length(y_test) * 100;

% 2. Polynomial Kernel (3rd order)
% One-vs-One
tic;
svm_poly_ovo = fitcecoc(W_training_norm, y_train, 'Coding', 'onevsone', ...
                       'Learners', templateSVM('KernelFunction', 'polynomial', 'PolynomialOrder', 3, 'Standardize', true));
training_time(2,1) = toc;
y_pred_poly_ovo = predict(svm_poly_ovo, W_testing_norm);
testing_accuracy(2,1) = sum(y_pred_poly_ovo == y_test) / length(y_test) * 100;

% One-vs-All
tic;
svm_poly_ova = fitcecoc(W_training_norm, y_train, 'Coding', 'onevsall', ...
                       'Learners', templateSVM('KernelFunction', 'polynomial', 'PolynomialOrder', 3, 'Standardize', true));
training_time(2,2) = toc;
y_pred_poly_ova = predict(svm_poly_ova, W_testing_norm);
testing_accuracy(2,2) = sum(y_pred_poly_ova == y_test) / length(y_test) * 100;

% 3. RBF Kernel
% One-vs-One
tic;
svm_rbf_ovo = fitcecoc(W_training_norm, y_train, 'Coding', 'onevsone', ...
                      'Learners', templateSVM('KernelFunction', 'rbf', 'Standardize', true));
training_time(3,1) = toc;
y_pred_rbf_ovo = predict(svm_rbf_ovo, W_testing_norm);
testing_accuracy(3,1) = sum(y_pred_rbf_ovo == y_test) / length(y_test) * 100;

% One-vs-All
tic;
svm_rbf_ova = fitcecoc(W_training_norm, y_train, 'Coding', 'onevsall', ...
                      'Learners', templateSVM('KernelFunction', 'rbf', 'Standardize', true));
training_time(3,2) = toc;
y_pred_rbf_ova = predict(svm_rbf_ova, W_testing_norm);
testing_accuracy(3,2) = sum(y_pred_rbf_ova == y_test) / length(y_test) * 100;

% Display results in table format
fprintf('Training Time (seconds) \n');
fprintf('One-vs-one   One-vs-all\n');
fprintf('Linear           %8.2f     %8.2f\n', training_time(1,1), training_time(1,2));
fprintf('Polynomial       %8.2f     %8.2f\n', training_time(2,1), training_time(2,2));
fprintf('RBF              %8.2f     %8.2f\n', training_time(3,1), training_time(3,2));

fprintf('Testing Accuracy\n');
fprintf('One-vs-one   One-vs-all\n');
fprintf('Linear           %8.2f     %8.2f\n', testing_accuracy(1,1), testing_accuracy(1,2));
fprintf('Polynomial       %8.2f     %8.2f\n', testing_accuracy(2,1), testing_accuracy(2,2));
fprintf('RBF              %8.2f     %8.2f\n', testing_accuracy(3,1), testing_accuracy(3,2));

% Compare with KNN
fprintf('\n KNN vs SVM Comparison \n');
fprintf('Best KNN accuracy: %.2f%%\n', max(accuracy_knn));
fprintf('Best SVM accuracy: %.2f%%\n', max(testing_accuracy(:)));
