function y_predict = weightedKNN(X_train, y_train, X_test, sigma)
    eucDistance = pdist2(X_test,X_train); %euclid distance formula
    weightFunc = exp(-eucDistance.^2/(sigma^2)); %weigths 
    
    uniqueClasses = unique(y_train); %Number of unique classes
    n = size(X_test, 1);

    y_predict = zeros(n, 1);
    
    for i = 1:n
        classScores = zeros(length(uniqueClasses),1);

        for index = 1:length(uniqueClasses)
            c = uniqueClasses(index);

            indicator = (y_train == c); %indicator function

            classScores(index) = sum(weightFunc(i, indicator));
        end
        [~,maxIndex] = max(classScores);
        y_predict(i) = uniqueClasses(maxIndex);
    end

    
end