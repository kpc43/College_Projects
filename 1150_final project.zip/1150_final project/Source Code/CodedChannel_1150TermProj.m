%This is channel coding implementation
%
% Parameters and Initialization
blkLen = 10;                % Block length (bits)
trellis = poly2trellis(4,[13 15],13);  % Trellis structure
n = log2(trellis.numOutputSymbols);    % Output bits per symbol
mLen = log2(trellis.numStates);        % Memory length

% Output Length Calculation
fullOut = (1:(mLen+blkLen)*2*n)';     % Full output indices
outLen = length(fullOut);              % Total output length
netRate = blkLen/outLen;               % Net coding rate

% Data Generation and Interleaver Creation
data = randi([0 1],blkLen,1);         % Random input data
intIndices = randperm(blkLen);         % Interleaver indices

% Turbo Encoder Configuration
turboEnc = comm.TurboEncoder('TrellisStructure',trellis);
turboEnc.InterleaverIndices = intIndices;
turboEnc.OutputIndicesSource = 'Property';
turboEnc.OutputIndices = fullOut;

% Turbo Decoder Configuration
turboDec = comm.TurboDecoder('TrellisStructure',trellis);
turboDec.InterleaverIndices = intIndices;
turboDec.InputIndicesSource = 'Property';
turboDec.InputIndices = fullOut;

% Open text file for writing results
fileID = fopen('coded_channel.txt','w');
fprintf(fileID, 'Iteration\tEncodeTime\tDecodeTime\tBER\t\tAccuracy\tThroughput\n');

% Initialize variables for averages
totalEncodeTime = 0;        % Total encoding time
totalDecodeTime = 0;        % Total decoding time
totalBER = 0;               % Total bit error rate
totalAccuracy = 0;          % Total accuracy
totalThroughput = 0;        % Total throughput

% Main simulation loop
for iter = 1:1000
    % Encoding with Delay Measurement
    encodeStart = tic;
    encMsg = turboEnc(data);
    encodeTime = toc(encodeStart);
    totalEncodeTime = totalEncodeTime + encodeTime;
    
    % Always add noise with low SNR
    snr = -200; % Low SNR to simulate noise, also chance that noise will be added for each transmission
    noise = randn(size(encMsg)) * sqrt(10^(-snr/10));
    rxSignal = 2*encMsg-1 + noise;
    
    % Decoding with Delay Measurement
    decodeStart = tic;
    rxMsg = turboDec(rxSignal);
    decodeTime = toc(decodeStart);
    totalDecodeTime = totalDecodeTime + decodeTime;
    
    % Bit Error Rate (BER) Calculation
    bitErrors = sum(data ~= rxMsg);
    ber = bitErrors / blkLen;
    totalBER = totalBER + ber;
    
    % Accuracy and Throughput Calculation
    accuracy = (1 - ber) * 100;
    totalAccuracy = totalAccuracy + accuracy;
    throughput = blkLen / (encodeTime + decodeTime);
    totalThroughput = totalThroughput + throughput;
    
    % Display results
    disp(['Iteration: ', num2str(iter)]);
    disp(['  Encoding Time: ', num2str(encodeTime*1000), ' ms']);
    disp(['  Decoding Time: ', num2str(decodeTime*1000), ' ms']);
    disp(['  Bit Error Rate: ', num2str(ber)]);
    disp(['  Accuracy: ', num2str(accuracy), '%']);
    disp(['  Throughput: ', num2str(throughput), ' bits/second']);
    disp('-----------------------------------');
    
    % Write to text file
    fprintf(fileID, '%d\t\t%.6f\t%.6f\t%.6f\t%.2f\t\t%.2f\n',...
            iter, encodeTime, decodeTime, ber, accuracy, throughput);
    
    % Pause for 1ms
    pause(0.001);
end

% Calculate averages
avgEncodeTime = totalEncodeTime / 1000;
avgDecodeTime = totalDecodeTime / 1000;
avgBER = totalBER / 1000;
avgAccuracy = totalAccuracy / 1000;
avgThroughput = totalThroughput / 1000;

% Display average results
disp(' ');
disp('=== AVERAGE RESULTS ===');
disp(['Average Encoding Time: ', num2str(avgEncodeTime*1000), ' ms']);
disp(['Average Decoding Time: ', num2str(avgDecodeTime*1000), ' ms']);
disp(['Average BER: ', num2str(avgBER)]);
disp(['Average Accuracy: ', num2str(avgAccuracy), '%']);
disp(['Average Throughput: ', num2str(avgThroughput), ' bits/second']);

% Write averages to file
fprintf(fileID, '\n=== AVERAGE RESULTS ===\n');
fprintf(fileID, 'Average Encoding Time: %.6f ms\n', avgEncodeTime*1000);
fprintf(fileID, 'Average Decoding Time: %.6f ms\n', avgDecodeTime*1000);
fprintf(fileID, 'Average BER: %.6f\n', avgBER);
fprintf(fileID, 'Average Accuracy: %.2f%%\n', avgAccuracy);
fprintf(fileID, 'Average Throughput: %.2f bits/second\n', avgThroughput);

% Close the text file
fclose(fileID);
disp('Simulation complete. Results saved to coded_channel.txt');