%% Uncoded Transmission Implementation
% ==================================

% Parameters
snr = -2;                  % Same SNR for comparison

% Initialize metrics
totalEncodeTime = 0;
totalDecodeTime = 0;
totalBER = 0;
totalAccuracy = 0;
totalThroughput = 0;

% File Setup
fileID = fopen('uncoded_channel.txt','w');
fprintf(fileID, 'Iteration\tEncodeTime(ms)\tDecodeTime(ms)\tBER\t\tAccuracy\tThroughput(bps)\n');

% Main simulation loop
for iter = 1:1000
    % Generate data
    data = randi([0 1], blkLen, 1);
    
    % "Encoding" (BPSK)
    encodeStart = tic;
    txSignal = 2*data - 1;
    encodeTime = toc(encodeStart);
    totalEncodeTime = totalEncodeTime + encodeTime;
    
    % Channel
    noise = randn(size(txSignal)) * sqrt(10^(-snr/10));
    rxSignal = txSignal + noise;
    
    % "Decoding" (threshold)
    decodeStart = tic;
    rxMsg = rxSignal > 0;
    decodeTime = toc(decodeStart);
    totalDecodeTime = totalDecodeTime + decodeTime;
    
    % Metric Calculation
    [ber, accuracy, throughput] = calculateMetrics(data, rxMsg, encodeTime, decodeTime, blkLen);
    totalBER = totalBER + ber;
    totalAccuracy = totalAccuracy + accuracy;
    totalThroughput = totalThroughput + throughput;
    
    % Display (same format as channel coding)
    displayResults(iter, encodeTime, decodeTime, ber, accuracy, throughput, 'Uncoded');
    
    % Save to file
    fprintf(fileID, '%d\t\t%.2f\t\t%.2f\t\t%.4f\t%.2f\t\t%.2f\n',...
            iter, encodeTime*1000, decodeTime*1000, ber, accuracy, throughput);
    
    pause(0.001);
end

% Calculate and display averages
displayAverages(totalEncodeTime, totalDecodeTime, totalBER, totalAccuracy, totalThroughput, 1000, 'Uncoded');

% Write averages to file
fprintf(fileID, '\n=== AVERAGE RESULTS ===\n');
fprintf(fileID, 'Average Encoding Time: %.2f ms\n', totalEncodeTime/1000*1000);
fprintf(fileID, 'Average Decoding Time: %.2f ms\n', totalDecodeTime/1000*1000);
fprintf(fileID, 'Average BER: %.4f\n', totalBER/1000);
fprintf(fileID, 'Average Accuracy: %.2f%%\n', totalAccuracy/1000);
fprintf(fileID, 'Average Throughput: %.2f bps\n', totalThroughput/1000);

fclose(fileID);

%% Helper Functions
function [ber, accuracy, throughput] = calculateMetrics(data, rxMsg, encodeTime, decodeTime, blkLen)
    bitErrors = sum(data ~= rxMsg);
    ber = bitErrors / blkLen;
    accuracy = (1 - ber) * 100;
    throughput = blkLen / (encodeTime + decodeTime);
end

function displayResults(iter, encodeTime, decodeTime, ber, accuracy, throughput, mode)
    disp(['[', mode, '] Iteration: ', num2str(iter)]);
    disp(['  Encoding Time: ', num2str(encodeTime*1000, '%.2f'), ' ms']);
    disp(['  Decoding Time: ', num2str(decodeTime*1000, '%.2f'), ' ms']);
    disp(['  Bit Error Rate: ', num2str(ber, '%.4f')]);
    disp(['  Accuracy: ', num2str(accuracy, '%.2f'), '%']);
    disp(['  Throughput: ', num2str(throughput, '%.2f'), ' bps']);
    disp('-----------------------------------');
end

function displayAverages(totalEncodeTime, totalDecodeTime, totalBER, totalAccuracy, totalThroughput, n, mode)
    disp(' ');
    disp(['=== [', mode, '] AVERAGE RESULTS ===']);
    disp(['Average Encoding Time: ', num2str(totalEncodeTime/n*1000, '%.6f'), ' ms']);
    disp(['Average Decoding Time: ', num2str(totalDecodeTime/n*1000, '%.6f'), ' ms']);
    disp(['Average BER: ', num2str(totalBER/n, '%.6f')]);
    disp(['Average Accuracy: ', num2str(totalAccuracy/n, '%.2f'), '%']);
    disp(['Average Throughput: ', num2str(totalThroughput/n, '%.2f'), ' bps']);
end