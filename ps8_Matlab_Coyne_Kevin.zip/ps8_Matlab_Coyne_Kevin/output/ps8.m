%{
cd('C:\Users\there\Downloads\ps8_Matlab_Coyne_Kevin');
addpath('C:\Users\there\Downloads\ps8_Matlab_Coyne_Kevin');

%Question 1
%part a
load("input\HW8_data1.mat");

samples = 20;
randNum = randperm(5000, samples);

X_imgs = reshape(X',[20,20,1,5000]);
%{
figure;
for i = 1:samples
    subplot(4,5,i);
    imshow(squeeze(X_imgs(:,:,1,randNum(i))));
    title([num2str(randNum(i))]);
end
saveas(gcf,'ps8-1-a-1.png');
%}
%part b
n = size(X,1);
idx = randperm(n);

splitData = round((4300/5000)*n); 
train_idx = idx(1:splitData);
test_idx = idx(splitData+1:end);

X_train = X(train_idx, :);
y_train = y(train_idx);

X_test = X(test_idx, :);
y_test = y(test_idx);

%part c

Xsamples = 860; %I assume you meant 860 because 4300/5 is 860 for training set, 1250 would work with 5000
Xi = cell(5,1);
yi = cell(5,1);

for i = 1:5
    randIndex = randi(size(X_train,1), Xsamples, 1);

    Xi{i} = X_train(randIndex, :);
    yi{i} = y_train(randIndex);
end

%part d
%SVM Classifier
fprintf('=== SVM CLASSIFIER ===\n');
C = 10;
sigma = 0.1;

%Train OnevsAll SVM Model via fitcecoc
SVMModel = fitcecoc(Xi{1}, yi{1}, ...
    'Learners', templateSVM('KernelFunction', 'gaussian', ...
                           'KernelScale', 1/sigma, ...
                           'BoxConstraint', C), ...
    'Coding', 'onevsall');

%numeral i:
y_pred_train1 = predict(SVMModel, Xi{1});
error_train1 = sum(y_pred_train1 ~= yi{1}) / length(yi{1});
fprintf('SVM Error on X1 (training): %.2f%%\n', error_train1*100);

%numeral ii:
fprintf('SVM Errors on other training subsets:\n');
error_train_not1 = zeros(4,1);

for i = 2:5
    y_pred_train = predict(SVMModel, Xi{i});
    error_train_not1(i-1) = sum(y_pred_train ~= yi{i}) / length(yi{i});
    fprintf('  X%d: %.2f%%\n', i, error_train_not1(i-1)*100);
end

%numeral iii:
y_pred_test = predict(SVMModel, X_test);
error_test = sum(y_pred_test ~= y_test) / length(y_test);
fprintf('SVM Error on test set: %.2f%%\n\n', error_test*100);

%part e
% KNN Classifier
fprintf('=== KNN CLASSIFIER ===\n');
K = 9;

%Train KNN w/ fitcknn
KNNModel = fitcknn(Xi{2}, yi{2}, 'NumNeighbors',K);

%numeral i
y_pred_train_KNN2 = predict(KNNModel, Xi{2});
error_train_KNN2 = sum(y_pred_train_KNN2 ~= yi{2}) / length(yi{2});
fprintf('KNN Error on X2: %.2f%%\n', error_train_KNN2*100);

%numeral ii
fprintf('KNN Errors on other training subsets:\n');
error_train_not2 = zeros(4,1);

for j = 1:4
    if j == 1
        y_pred_train_KNN1 = predict(KNNModel,Xi{1});
        error_train_not2(1) = sum(y_pred_train_KNN1 ~= yi{1}) / length(yi{1});
        fprintf('  X1: %.2f%%\n', error_train_not2(1)*100);
    else
        y_pred_train_KNN = predict(KNNModel, Xi{j+1});
        error_train_not2(j) = sum(y_pred_train_KNN ~= yi{j+1}) / length(yi{j+1});
        fprintf('  X%d: %.2f%%\n', j+1, error_train_not2(j)*100);
    end
end

%numeral iii
y_pred_test_KNN = predict(KNNModel, X_test);
error_test_KNN = sum(y_pred_test_KNN ~= y_test) / length(y_test);
fprintf('KNN Error on test set: %.2f%%\n\n', error_test_KNN*100);

%part f
%Logistic Regression Classifier
fprintf('=== Logistic Regression CLASSIFIER ===\n');

LogRegModel = fitcecoc(Xi{3}, yi{3}, ...
    'Learners', templateLinear('Learner', 'logistic'), ...
    'Coding', 'onevsall');

%numeral i
y_pred_train3 = predict(LogRegModel, Xi{3});
error_train3 = sum(y_pred_train3 ~= yi{3}) / length(yi{3});
fprintf('Logistic Regression Error on X3 (training): %.2f%%\n', error_train3*100);

%numeral ii
fprintf('Logistic Regression Errors on other training subsets:\n');
error_train_not3 = zeros(4,1);
subset_indices = [1, 2, 4, 5];

for i = 1:4
    idx = subset_indices(i);
    y_pred_train = predict(LogRegModel, Xi{idx});
    error_train_not3(i) = sum(y_pred_train ~= yi{idx}) / length(yi{idx});
    fprintf('  X%d: %.2f%%\n', idx, error_train_not3(i)*100);
end

%numeral iii
y_pred_test_logreg = predict(LogRegModel, X_test);
error_test_logreg = sum(y_pred_test_logreg ~= y_test) / length(y_test);
fprintf('Logistic Regression Error on test set: %.2f%%\n\n', error_test_logreg*100);

%part g
%Neural Network Classifier
fprintf('=== NEURAL NETWORK CLASSIFIER ===\n');

NNModel = fitcnet(Xi{4}, yi{4}, ...
    'LayerSizes', [10], ...  % Small hidden layer to limit capacity
    'Activations', 'relu', ...
    'Lambda', 1, ...         % Strong regularization
    'IterationLimit', 50);   % Limited training

%numeral i
y_pred_train4 = predict(NNModel, Xi{4});
error_train4 = sum(y_pred_train4 ~= yi{4}) / length(yi{4});
fprintf('Neural Network Error on X4 (training): %.2f%%\n', error_train4*100);

% numeral ii
fprintf('Neural Network Errors on other training subsets:\n');
error_train_not4 = zeros(4,1);
subset_indices = [1, 2, 3, 5];

for i = 1:4
    idx = subset_indices(i);
    y_pred_train = predict(NNModel, Xi{idx});
    error_train_not4(i) = sum(y_pred_train ~= yi{idx}) / length(yi{idx});
    fprintf('  X%d: %.2f%%\n', idx, error_train_not4(i)*100);
end

% numeral iii
y_pred_test_nn = predict(NNModel, X_test);
error_test_nn = sum(y_pred_test_nn ~= y_test) / length(y_test);
fprintf('Neural Network Error on test set: %.2f%%\n\n', error_test_nn*100);


%part h
%Random forest 12 trees classifier
%https://www.mathworks.com/help/stats/treebagger.html
fprintf('=== RANDOM FOREST CLASSIFIER (12 Trees) ===\n');

trees = 12;

RFModel = TreeBagger(trees, Xi{5}, yi{5}, 'Method', 'classification');

%numeral i
y_pred_train5 = predict(RFModel, Xi{5});
y_pred_train5 = str2double(y_pred_train5);
error_train5 = sum(y_pred_train5 ~= yi{5}) / length(yi{5});
fprintf('Random Forest Error on X5 (training): %.2f%%\n', error_train5*100);

%numeral ii
fprintf('Random Forest Errors on other training subsets:\n');
error_train_not5 = zeros(4,1);
subset_indices = [1, 2, 3, 4];

for i = 1:4
    idx = subset_indices(i);
    y_pred_train = predict(RFModel, Xi{idx});
    y_pred_train = str2double(y_pred_train);
    error_train_not5(i) = sum(y_pred_train ~= yi{idx}) / length(yi{idx});
    fprintf('  X%d: %.2f%%\n', idx, error_train_not5(i)*100);
end

%numeral iii
y_pred_test_rf = predict(RFModel, X_test);
y_pred_test_rf = str2double(y_pred_test_rf);
error_test_rf = sum(y_pred_test_rf ~= y_test) / length(y_test);
fprintf('Random Forest Error on test set: %.2f%%\n\n', error_test_rf*100);

%part i
svm_pred = predict(SVMModel, X_test);
knn_pred = predict(KNNModel, X_test);
logreg_pred = predict(LogRegModel, X_test);
nn_pred = predict(NNModel, X_test);
rf_pred = predict(RFModel, X_test);
rf_pred = str2double(rf_pred); % Convert Random Forest predictions

all_predictions = [svm_pred, knn_pred, logreg_pred, nn_pred, rf_pred];
% Apply majority voting
ensemble_pred = mode(all_predictions, 2);

% Calculate ensemble error rate
ensemble_error = sum(ensemble_pred ~= y_test) / length(y_test);
fprintf('Ensemble Error Rate: %.2f%%\n', ensemble_error*100);

% Display individual classifier errors 
fprintf('\nIndividual Classifier Errors on Test Set:\n');
fprintf('SVM:                %.2f%%\n', error_test*100);
fprintf('KNN:                %.2f%%\n', error_test_KNN*100);
fprintf('Logistic Regression: %.2f%%\n', error_test_logreg*100);
fprintf('Neural Network:     %.2f%%\n', error_test_nn*100);
fprintf('Random Forest:      %.2f%%\n', error_test_rf*100);
fprintf('Ensemble:           %.2f%%\n', ensemble_error*100);
%}
%Question 2 
%part a and b- look at functions
%part c
%part c - Save images to files for easy viewing
cd('C:\Users\there\Downloads\ps8_Matlab_Coyne_Kevin\input\HW8_F_images');
addpath('C:\Users\there\Downloads\ps8_Matlab_Coyne_Kevin\input\HW8_F_images');

im1 = imread('im1.jpg');
im2 = imread('im2.jpg');
im3 = imread('im3.png');

images = {im1, im2, im3};
image_names = {'Image 1', 'Image 2', 'Image 3'};

% Parameters
K_values = [3, 5, 7];
iters_values = [7, 15, 25];
R_values = [5, 8, 12];

% Create output folder
output_dir = 'rotated_comparisons';
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% Grid 1: Original assignment (K, iters, R)
figure('Position', [100, 100, 1400, 1200], 'Name', 'Grid 1: K-iters-R');

% Row 1: Image 1 - Varying K values
for k_idx = 1:3
    subplot(3, 3, k_idx);
    im_segmented = Segment_kmeans(images{1}, K_values(k_idx), 15, 8);
    imshow(im_segmented);
    title(sprintf('Image 1\nK=%d (iters=15, R=8)', K_values(k_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

% Row 2: Image 2 - Varying iterations
for iter_idx = 1:3
    subplot(3, 3, 3 + iter_idx);
    im_segmented = Segment_kmeans(images{2}, 5, iters_values(iter_idx), 8);
    imshow(im_segmented);
    title(sprintf('Image 2\niters=%d (K=5, R=8)', iters_values(iter_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

% Row 3: Image 3 - Varying R values
for r_idx = 1:3
    subplot(3, 3, 6 + r_idx);
    im_segmented = Segment_kmeans(images{3}, 5, 15, R_values(r_idx));
    imshow(im_segmented);
    title(sprintf('Image 3\nR=%d (K=5, iters=15)', R_values(r_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

sgtitle('Grid 1: Image1=K, Image2=iters, Image3=R', 'FontSize', 16, 'FontWeight', 'bold');
saveas(gcf, fullfile(output_dir, 'grid1_K_iters_R.png'));

% Grid 2: Rotated assignment (iters, R, K)
figure('Position', [100, 100, 1400, 1200], 'Name', 'Grid 2: iters-R-K');

% Row 1: Image 1 - Varying iterations
for iter_idx = 1:3
    subplot(3, 3, iter_idx);
    im_segmented = Segment_kmeans(images{1}, 5, iters_values(iter_idx), 8);
    imshow(im_segmented);
    title(sprintf('Image 1\niters=%d (K=5, R=8)', iters_values(iter_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

% Row 2: Image 2 - Varying R values
for r_idx = 1:3
    subplot(3, 3, 3 + r_idx);
    im_segmented = Segment_kmeans(images{2}, 5, 15, R_values(r_idx));
    imshow(im_segmented);
    title(sprintf('Image 2\nR=%d (K=5, iters=15)', R_values(r_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

% Row 3: Image 3 - Varying K values
for k_idx = 1:3
    subplot(3, 3, 6 + k_idx);
    im_segmented = Segment_kmeans(images{3}, K_values(k_idx), 15, 8);
    imshow(im_segmented);
    title(sprintf('Image 3\nK=%d (iters=15, R=8)', K_values(k_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

sgtitle('Grid 2: Image1=iters, Image2=R, Image3=K', 'FontSize', 16, 'FontWeight', 'bold');
saveas(gcf, fullfile(output_dir, 'grid2_iters_R_K.png'));

% Grid 3: Final rotation (R, K, iters)
figure('Position', [100, 100, 1400, 1200], 'Name', 'Grid 3: R-K-iters');

% Row 1: Image 1 - Varying R values
for r_idx = 1:3
    subplot(3, 3, r_idx);
    im_segmented = Segment_kmeans(images{1}, 5, 15, R_values(r_idx));
    imshow(im_segmented);
    title(sprintf('Image 1\nR=%d (K=5, iters=15)', R_values(r_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

% Row 2: Image 2 - Varying K values
for k_idx = 1:3
    subplot(3, 3, 3 + k_idx);
    im_segmented = Segment_kmeans(images{2}, K_values(k_idx), 15, 8);
    imshow(im_segmented);
    title(sprintf('Image 2\nK=%d (iters=15, R=8)', K_values(k_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

% Row 3: Image 3 - Varying iterations
for iter_idx = 1:3
    subplot(3, 3, 6 + iter_idx);
    im_segmented = Segment_kmeans(images{3}, 5, iters_values(iter_idx), 8);
    imshow(im_segmented);
    title(sprintf('Image 3\niters=%d (K=5, R=8)', iters_values(iter_idx)), 'FontSize', 11, 'FontWeight', 'bold');
end

sgtitle('Grid 3: Image1=R, Image2=K, Image3=iters', 'FontSize', 16, 'FontWeight', 'bold');
saveas(gcf, fullfile(output_dir, 'grid3_R_K_iters.png'));

fprintf('All 3 rotated grids saved to %s folder\n', output_dir);