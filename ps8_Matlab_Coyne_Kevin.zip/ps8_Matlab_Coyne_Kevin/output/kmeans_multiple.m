function [ids, means, ssd] = kmeans_multiple(X, K, iters, R)
    best_ssd = inf;
    best_ids = [];
    best_means = [];
    
    % Run K-means R times with different random initializations
    for r = 1:R
        [current_ids, current_means, current_ssd] = kmeans_single(X, K, iters);
        
        % Keep track of the best result 
        if current_ssd < best_ssd
            best_ssd = current_ssd;
            best_ids = current_ids;
            best_means = current_means;
        end
    end
    
    % Return the best result found
    ids = best_ids;
    means = best_means;
    ssd = best_ssd;
end