function [im_out] = Segment_kmeans(im_in, K, iters, R)

% Convert to double and resize to reduce computation time
    im = im2double(im_in);
    im = imresize(im, [100 100]);
    
    % Get image dimensions
    [H, W, ~] = size(im);
    
    % Reshape image to data matrix: (H*W) x 3
    X = reshape(im, H * W, 3);
    
    % Perform K-means clustering on pixel colors
    [ids, means, ~] = kmeans_multiple(X, K, iters, R);
    
    % Recolor each pixel with its cluster center
    X_recolored = zeros(size(X));
    for k = 1:K
        cluster_pixels = (ids == k);
        X_recolored(cluster_pixels, :) = repmat(means(k, :), sum(cluster_pixels), 1);
    end
    
    % Reshape back to image format
    im_recolored = reshape(X_recolored, H, W, 3);
    
    % Convert back to uint8 for display
    im_out = im2uint8(im_recolored);
end