function [ids, means, ssd] = kmeans_single(X, K, iters)
    
[m, n] = size(X);
    
    % Initialize cluster centers randomly within data range
    means = zeros(K, n);
    for dim = 1:n
        min_val = min(X(:, dim));
        max_val = max(X(:, dim));
        range_val = max_val - min_val;
        means(:, dim) = min_val + range_val * rand(K, 1);
    end
    
    % Initialize cluster assignments
    ids = zeros(m, 1);
    

    for iter = 1:iters
    % Assign points to nearest clusters
        distances = pdist2(X, means);
        [~, ids] = min(distances, [], 2);
        
        %Update cluster centers
        for k = 1:K
            cluster_points = X(ids == k, :);
            if ~isempty(cluster_points)
                means(k, :) = mean(cluster_points, 1);
            else
                % If cluster is empty, reinitialize randomly
                for dim = 1:n
                    min_val = min(X(:, dim));
                    max_val = max(X(:, dim));
                    range_val = max_val - min_val;
                    means(k, dim) = min_val + range_val * rand();
                end
            end
        end
    end
    
    % Calculate final SSD
    ssd = 0;
    for k = 1:K
        cluster_points = X(ids == k, :);
        if ~isempty(cluster_points)
            diff = cluster_points - means(k, :);
            squared_distances = sum(diff.^2, 2);
            ssd = ssd + sum(squared_distances);
        end
    end
end