%Best to comment and uncomment each question because some variables are the
%same for some questions

%Question 1
%{
%part b
load('hw4_data1.mat');

X = [ones(size(y)), X_data];

%disp(size(X));

%part c
n = size(X, 1);
lambda = [0 0.001 0.003 0.005 0.007 0.009 0.012 0.017];


train_errors = zeros(20, length(lambda));
test_errors = zeros(20, length(lambda));

for iter = 1:20 
    idx = randperm(n);
    DataSplit = round(0.85 * n);
    
    train_idx = idx(1:DataSplit);
    test_idx = idx(DataSplit+1:end);
    
    X_train = X(train_idx, :);
    y_train = y(train_idx);
    X_test = X(test_idx, :);
    y_test = y(test_idx);
    
    for i = 1:length(lambda)
        theta = Reg_normalEqn(X_train, y_train, lambda(i));
        
        train_errors(iter, i) = computeCost(X_train, y_train, theta);
        test_errors(iter, i) = computeCost(X_test, y_test, theta);
    end
end

avg_train_errors = mean(train_errors, 1);
avg_test_errors = mean(test_errors, 1);

figure;
plot(lambda, avg_train_errors, 'b-o', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Average Training Error');
hold on;
plot(lambda, avg_test_errors, 'r-s', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Average Testing Error');
xlabel('Regularization Parameter \lambda');
ylabel('Average Error');
title('Average Training and Testing Error vs \lambda');
legend('show');
grid on;

ylim([3.11, 3.18]);

saveas(gcf, 'ps4-1-a.png');

for i = 1:length(lambda)
    fprintf('%.4f\t\t%.6f\t\t%.6f\n', lambda(i), avg_train_errors(i), avg_test_errors(i));
end
%}
%Question 2

%{
load('hw4_data2.mat');

K_values = 1:2:15;
num_folds = 5;
accuracies = zeros(num_folds, length(K_values));

for fold = 1:num_folds
    test_fold = fold;
    train_folds = setdiff(1:5, test_fold);
    
    X_train2 = [];
    y_train2 = [];
    for i = 1:length(train_folds)
        X_train2 = [X_train2; eval(['X' num2str(train_folds(i))])];
        y_train2 = [y_train2; eval(['y' num2str(train_folds(i))])];
    end
    
    X_test2 = eval(['X' num2str(test_fold)]);
    y_test2 = eval(['y' num2str(test_fold)]);
    
    for k_idx = 1:length(K_values)
        K = K_values(k_idx);
        
        % Manual KNN implementation
        %Because of the version of matlab I am using fitcknn is not
        %avaliable unless I intall simulinks software so I manuelly
        %implemnted it, source: https://www.mathworks.com/help/stats/fitcknn.html
        y_pred = zeros(size(y_test2));
        for i = 1:size(X_test2, 1)
            distances = sqrt(sum((X_train2 - X_test2(i,:)).^2, 2));
            [~, idx] = sort(distances);
            nearest_labels = y_train2(idx(1:K));
            y_pred(i) = mode(nearest_labels);
        end
        
        accuracy = sum(y_pred == y_test2) / length(y_test2);
        accuracies(fold, k_idx) = accuracy;
    end
end

avg_accuracies = mean(accuracies, 1);

figure;
plot(K_values, avg_accuracies, 'b-o', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('K Value');
ylabel('Average Accuracy');
title('KNN Classification: Average Accuracy vs K');
grid on;

for i = 1:length(K_values)
    text(K_values(i), avg_accuracies(i) + 0.005, sprintf('%.3f', avg_accuracies(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 9);
end

saveas(gcf, 'ps4-2-a.png');
%}
%Question 3
%part a
load('hw4_data3.mat');

y_predict_train = logReg_multi(X_train, y_train, X_train);
y_predict_test = logReg_multi(X_train, y_train, X_test);

accuracyTest = sum(y_predict_test == y_test)/length(y_test);
accuracyTrain = sum(y_predict_train == y_train)/length(y_train);
%Reference: https://www.mathworks.com/help/matlab/matlab_prog/create-a-table.html
tbl = table(accuracyTrain,accuracyTest, 'VariableNames',{'TrainingAccuracy','TestingAcuracy'});
disp(tbl);


