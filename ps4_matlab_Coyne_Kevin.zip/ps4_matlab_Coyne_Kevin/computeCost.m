function J = computeCost(X, y, theta)

m = length(y); %training samples

hypothesis = X*theta; 

constant = (1/(2*m));
squaredErrors = (hypothesis - y).^2;

J = constant * sum(squaredErrors); %Calculate cost
end