function y_predict = logReg_multi(X_train, y_train, X_test)
    %Reference: https://www.mathworks.com/help/matlab/ref/double.unique.html
    C = unique(y_train);
    num_C = length(C);
    Mdl_c = cell(num_C,1);

    prob_matrix = zeros(size(X_test, 1), num_C);

    for i = 1:num_C
        current_C = C(i);
%binary label for current class
        y_c = (y_train == current_C);
        
        %FYI: I realized I can use fitclinear and other statistics and ML tools, I just had to install the add on,
        %I will not go back and change Question 2 because it works fine as
        %is
        Mdl_c{i} = fitclinear(X_train,y_c,'learner','logistic');
%prob for test set of pos class
        [~,proba_c] = predict(Mdl_c{i}, X_test);
        prob_matrix(:, i) = proba_c(:, 2);

    end
    %predicts class with highest prob
    [~, max_prob_idx] = max(prob_matrix, [], 2);
    y_predict  = C(max_prob_idx);

end