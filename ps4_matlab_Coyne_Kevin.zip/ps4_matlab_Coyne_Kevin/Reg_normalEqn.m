%part a
function [theta] = Reg_normalEqn(X_train, y_train, lambda)
    [m, n] = size(X_train); % m will be unused
    D = eye(n);
    D(1,1) = 0;
    if lambda > 0
        theta = (X_train'*X_train+lambda*D)\(X_train'*y_train);
    else
        theta = (X_train'*X_train)\(X_train'*y_train);
    end 
end
